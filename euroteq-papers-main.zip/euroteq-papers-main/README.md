# To Run
`streamlit run app.py`

## Python version 3.10.13 was used for developing this, but you will probably be fine with most other versions as well (3.8+)
## On 'requirements.txt' we have too many packages (far more than necessary) so it might be more efficient to just indiidually download lacking packages. Sorry for this, didn't create a venv.



